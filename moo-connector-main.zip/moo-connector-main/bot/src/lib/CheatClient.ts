import type Player from "../instance/Player";
import EventDriven from "../utils/EventDriven";
import atan2 from "../utils/atan2";
import hypot from "../utils/hypot";
import sleep from "../utils/sleep";
import Client from "./Client";

interface CheatConfig {
    AutoHeal: "disable" | "enable" | "never";
}

const DEFAULT_CONFIG: CheatConfig = {
    AutoHeal: "enable",
};

export default class CheatClient extends EventDriven<{}, CheatClient> {
    readonly config: CheatConfig;
    readonly mouse: { x: number; y: number; angle: number } = {
        angle: 0,
        x: 0,
        y: 0,
    };

    public enemies: Player[] = [];

    constructor(readonly client: Client, config: Partial<CheatConfig>) {
        super();
        this.config = {
            ...DEFAULT_CONFIG,
            ...config,
        };
        this.__init_listeners__();
    }

    private __init_listeners__() {
        // TODO: Remove listeners when cleanup

        this.client.on("update", () => {
            const myPlayer = this.client.myPlayer;

            if (!myPlayer) {
                this.enemies = [];
                return;
            }

            const visiblePlayers = Array.from(this.client.players.values())
                .filter((e) => e.visible)
                .sort((a, b) => hypot(a, myPlayer) - hypot(b, myPlayer));

            this.enemies = visiblePlayers.filter(
                (e) =>
                    (e.teamID != myPlayer.teamID || myPlayer.teamID == null) &&
                    myPlayer.id != e.id
            );
        });

        // AutoHeal
        if (this.config.AutoHeal != "never")
            this.client.on("healthChange", async () => {
                if (this.config.AutoHeal == "disable") return;

                await sleep(40);

                if ((this.client.myPlayer?.health || 0) < 90)
                    this.client.place(this.client.foodType);
            });
    }

    get nearestEnemy() {
        return this.enemies[0] || null;
    }

    async instantKill(player?: Player) {
        if (!this.client.myPlayer) return;

        const angle = player
            ? atan2(player, this.client.myPlayer)
            : this.enemies[0]
            ? atan2(this.enemies[0], this.client.myPlayer)
            : this.mouse.angle;

        // If tail, remove.
        if (this.client.myPlayer?.tailID == 11) {
            this.client.equipWing("Naked"); // TODO: Pick better wings bro!
            await sleep(70);
        }

        this.client.equipHat("Bull Helmet");
        this.client.hold(this.client.primaryWeapon, "weapon");
        this.client.setAutoFire(true, angle);

        if (this.client.secondaryWeapon !== null) {
            await sleep(110);

            this.client.hold(this.client.secondaryWeapon, "weapon");
            this.client.equipHat("Turret Gear");
        }

        await sleep(120);
        this.client.equipHat("Booster Hat");
        this.client.hold(this.client.primaryWeapon, "weapon");
        this.client.setAutoFire(false);
    }

    async geographyGear() {
        const biome = this.client.myPlayer?.biome || "Land";
        this.client.equipHat(
            biome == "Land"
                ? "Booster Hat"
                : biome == "River"
                ? "Flipper Hat"
                : "Winter Cap"
        );
        await sleep(70); // to equip the monkey tail
        this.client.equipWing("Monkey Tail");
    }
}
