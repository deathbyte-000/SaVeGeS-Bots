import msgpack from "msgpack-lite";
import WebSocket from "ws";

import GameAI from "../instance/GameAI";
import GameObject from "../instance/GameObject";
import Player from "../instance/Player";
import {
    APacketSchema,
    HPacketSchema,
    IPacketSchema,
} from "../instance/Schema";
import EventDriven from "../utils/EventDriven";

const DEFAULT_KIT = [0, 3, 6, 10];

export default class ClientState extends EventDriven<
    {
        ready: null;

        spawn: null;
        death: null;

        healthChange: {
            prevHealth: number;
            currHealth: number;
        };

        chat: {
            player: Player;
            message: string;
        };

        "age-up": number;

        TeamSignal: {
            x: number;
            y: number;
        };

        update: null;

        send: [string, any[]];
    },
    ClientState
> {
    public state: Record<string, any> = {};

    public secondaryWeapon: number | null = 0;
    public primaryWeapon: number = 0;
    public kit = [...DEFAULT_KIT];

    public myPlayer: null | Player = null;
    private myPlayerID: number | null = null;

    readonly players = new Map<number, Player>(); // ID, Player
    public gameObjects = new Array<GameObject>();
    public gameAIs = new Array<GameAI>();

    readonly resources: {
        points: number;
        wood: number;
        food: number;
        stone: number;
    } = {
        points: 0,
        wood: 0,
        food: 0,
        stone: 0,
    };

    constructor(readonly socket: WebSocket) {
        super();

        this.socket.addEventListener("message", ({ data }) => {
            if (
                data instanceof Buffer ||
                Buffer.isBuffer(data) ||
                data instanceof ArrayBuffer
            ) {
                const message = msgpack.decode(new Uint8Array(data));

                this.onMessage(message);
            }
        });

        const oldSend = this.socket.send.bind(this.socket);
        this.socket.send = (data) => {
            if (data instanceof Uint8Array)
                this.emit("send", msgpack.decode(data));

            oldSend(data);
        };
    }

    private onMessage(message: [string, any[]]) {
        const [messageID, data] = message;

        switch (messageID) {
            case "io-init": {
                this.emit("ready", null);
                break;
            }

            case "D": {
                if (data[1]) {
                    this.myPlayerID = data[0][1];
                    this.kit = [...DEFAULT_KIT];

                    this.primaryWeapon = 0;
                    this.secondaryWeapon = null;

                    this.emit("spawn", null);
                }
                break;
            }

            case "T": {
                this.emit("age-up", data[2]);
                break;
            }

            case "6": {
                const [id, message] = data;

                const player = this.players.get(id);
                player &&
                    this.emit("chat", {
                        player,
                        message,
                    });

                break;
            }

            case "P": {
                this.myPlayerID = -1;
                this.emit("death", null);
                break;
            }

            case "9": {
                this.emit("TeamSignal", {
                    x: data[0],
                    y: data[1],
                });
                break;
            }

            case "V": {
                if (data[1] === 1) {
                    this.primaryWeapon = data[0][0];
                    this.secondaryWeapon = data[0][1] || null;
                } else {
                    this.kit = data[0];
                }
                break;
            }

            case "N": {
                if (data[0] in this.resources) {
                    // @ts-expect-error
                    this.resources[data[0]] = data[1];
                }
                break;
            }

            case "a": {
                this.players.forEach((p) => (p.visible = false));
                for (let i = 0; i < data[0].length; i += 13) {
                    const slice = APacketSchema.parse(data[0].slice(i, i + 13));
                    const [id] = slice;

                    if (!this.players.has(id)) {
                        this.players.set(id, new Player(id, slice));
                    }

                    const player = this.players.get(id);

                    if (!player) continue;

                    player.update(slice);

                    if (player.id == this.myPlayerID) {
                        this.myPlayer = player;
                    }
                }

                this.emit("update", null);
                break;
            }

            case "O": {
                const player = this.players.get(data[0]);

                if (!player) break;
                const prevHealth = player.health;
                player.setHealth(data[1]);

                player.id == this.myPlayer?.id &&
                    this.emit("healthChange", {
                        currHealth: player.health,
                        prevHealth,
                    });
                break;
            }

            case "H": {
                for (let i = 0; i < data[0].length; i += 8) {
                    const slice = HPacketSchema.parse(data[0].slice(i, i + 8));
                    const obj = new GameObject(slice[0], slice);

                    this.gameObjects.push(obj);
                }
                break;
            }

            case "Q": {
                this.gameObjects = this.gameObjects.filter(
                    (e) => e.id !== data[0]
                );
                break;
            }

            case "I": {
                this.gameAIs = [];

                if (!data[0]) break;
                for (let i = 0; i < data[0].length; i += 7) {
                    const slice = IPacketSchema.parse(data[0].slice(i, i + 7));
                    const obj = new GameAI(slice[0], slice);

                    this.gameAIs.push(obj);
                }
                break;
            }

            default: {
                // console.log(messageID, data);
                break;
            }
        }
    }

    public sendPacket(...packet: [string, ...any]) {
        if (this.socket.readyState != this.socket.OPEN)
            return console.warn("Socket is not opened yet.");

        const pack = [packet[0], packet.slice(1)];
        this.socket.send(msgpack.encode(pack));
    }

    get foodType() {
        return this.kit[0]!;
    }
    get wallType() {
        return this.kit[1]!;
    }
    get spikeType() {
        return this.kit[2]!;
    }
    get millType() {
        return this.kit[3]!;
    }
    get boostType() {
        return this.kit[4] ?? -1;
    }
    get turretType() {
        const haveMine = this.kit[5] == 13 || this.kit[5] == 14;
        return this.kit[5 + +haveMine]!;
    }

    get isAlive() {
        return this.myPlayer != null;
    }
}
