import { Hats, SKIN_MAP, Wings } from "../config";
import ClientState from "./ClientState";

export type WingName = (typeof Wings)[number]["name"] | "Naked";
export type HatName = (typeof Hats)[number]["name"] | "Naked";

export default class Client extends ClientState {
    spawn(name: string, skin: keyof typeof SKIN_MAP) {
        const skinID = SKIN_MAP[skin] ?? 0;

        this.sendPacket("M", { name, skin: skinID, moofoll: "1" });
    }

    setAutoFire(state: boolean, direction?: Direction) {
        this.sendPacket("d", state, direction ?? null);
    }

    setDirection(direction: Direction) {
        this.sendPacket("D", direction);
    }

    setMovementDirection(direction: Direction | "STOP") {
        this.sendPacket("a", direction == "STOP" ? null : direction);
    }

    createClan(clanName: string) {
        this.sendPacket("L", clanName);
    }

    sendJoinRequest(clanName: string) {
        this.sendPacket("b", clanName);
    }

    answerJoinRequest(playerID: ID, answer: "Reject" | "Accept" | "X" | "✔") {
        this.sendPacket("P", playerID, answer == "Accept" || answer == "✔");
    }

    kickFromClan(playerID: ID) {
        this.sendPacket("Q", playerID);
    }

    leaveClan() {
        this.sendPacket("N");
    }

    chat(message: string) {
        this.sendPacket("6", message);
    }

    equipHat(hat: HatName | number) {
        let hatID;

        if (typeof hat !== "number") {
            const lowHat = hat.toLowerCase();
            hatID =
                Hats.find((h) => h.name.toLowerCase() == lowHat)?.id ??
                (hat == "Naked" ? 0 : null);

            if (hatID === null)
                return console.warn("cannot find hat[" + hat + "]");
        } else {
            hatID = hat;
        }

        this.sendPacket("c", 0, hatID, 0);
    }

    buyHat(hat: HatName | number) {
        let hatID;

        if (typeof hat !== "number") {
            const lowHat = hat.toLowerCase();
            hatID =
                Hats.find((h) => h.name.toLowerCase() == lowHat)?.id ??
                (hat == "Naked" ? 0 : null);

            if (hatID === null)
                return console.warn("cannot find hat[" + hat + "]");
        } else {
            hatID = hat;
        }

        this.sendPacket("c", 1, hatID, 0);
    }

    equipWing(wing: WingName | number) {
        let wingID;

        if (typeof wing !== "number") {
            const lowWing = wing.toLowerCase();
            wingID =
                Wings.find((h) => h.name.toLowerCase() == lowWing)?.id ??
                (wing == "Naked" ? 0 : null);

            if (wingID === null)
                return console.warn("cannot find wing[" + wing + "]");
        } else {
            wingID = wing;
        }

        this.sendPacket("c", 0, wingID, 1);
    }

    buyWing(wing: WingName | number) {
        let wingID;

        if (typeof wing !== "number") {
            const lowWing = wing.toLowerCase();
            wingID =
                Wings.find((h) => h.name.toLowerCase() == lowWing)?.id ??
                (wing == "Naked" ? 0 : null);

            if (wingID === null)
                return console.warn("cannot find wing[" + wing + "]");
        } else {
            wingID = wing;
        }

        this.sendPacket("c", 1, wingID, 1);
    }

    select(id: number) {
        this.sendPacket("H", id);
    }

    hold(id: number, type: "item" | "weapon") {
        this.sendPacket("G", id, type == "weapon");
    }

    place(id: number, angle = this.myPlayer?.angle || 0) {
        if (typeof id !== "number" || id == -1) return;

        this.hold(id, "item");
        this.setAutoFire(true, angle);
        this.setAutoFire(false, angle);
        this.hold(
            this.myPlayer?.weaponType ?? this.primaryWeapon ?? 0,
            "weapon"
        );
    }

    public getUrl() {
        return this.socket.url.split("?token=")[0]!;
    }
}
