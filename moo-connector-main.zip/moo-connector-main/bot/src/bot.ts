import WebSocket from "ws";
import Client from "./lib/Client";
import CheatClient from "./lib/CheatClient";
import hypot from "./utils/hypot";
import atan2 from "./utils/atan2";
import Entity from "./instance/Entity";
import sleep from "./utils/sleep";

function initClient(client: Client, cheat: CheatClient) {
    let tick = 0;
    let teamSignalLocation: null | {
        x: number;
        y: number;
    } = null;

    const BotState: {
        moveDir: number | "STOP";
        lookAt: number | null;
        fire: boolean;
    } = {
        moveDir: "STOP",
        lookAt: null,
        fire: true,
    };

    const spawn = () => {
        client.spawn("IBot", "Brown");
        BotState.fire = true;
    };

    client.on("update", function () {
        if (!client.myPlayer) return;

        const myPlayer = client.myPlayer;

        this.gameObjects.sort(
            (a, b) => hypot(a, myPlayer) - hypot(b, myPlayer)
        );

        const closestTrap = this.gameObjects.find((e) => e.dataIndex == 15);

        // If the bot inside a trap.
        if (closestTrap && hypot(closestTrap, myPlayer) <= 35 * 2) {
            const trapOwner = client.players.get(closestTrap.ownerID);

            if (
                !trapOwner ||
                (trapOwner.teamID != myPlayer.teamID &&
                    myPlayer.teamID !== null)
            ) {
                BotState.lookAt = atan2(closestTrap, myPlayer);
                return;
            }
        }

        const ais = client.gameAIs.sort(
            (a, b) => hypot(a, myPlayer) - hypot(b, myPlayer)
        );

        const bull = ais.find((e) => e.aiType == "Bull" || e.aiType == "Bully");

        // Anti-Bull:
        if (bull && hypot(bull, myPlayer) <= 210) {
            client.place(client.spikeType, atan2(bull, myPlayer));
        }

        // If bot get near the signal location, cancel it.
        if (teamSignalLocation && hypot(teamSignalLocation, myPlayer) <= 100) {
            teamSignalLocation = null;
        }

        // If signal location is sent, keep following it until you reach it.
        if (teamSignalLocation) {
            BotState.lookAt = atan2(teamSignalLocation, myPlayer);
            BotState.moveDir = BotState.lookAt;

            return;
        }

        if (cheat.nearestEnemy) {
            BotState.lookAt = atan2(cheat.nearestEnemy, myPlayer);
            BotState.moveDir = BotState.lookAt;

            const dist = hypot(cheat.nearestEnemy, myPlayer);

            // If enemy is 250 meters far. place boost towards him
            if (dist > 250) {
                client.place(client.boostType, BotState.lookAt);
            }

            // If enemy is too close: place spike
            if (dist <= 100) {
                client.place(client.spikeType, BotState.lookAt);
            }

            // If enemy is close wear a solider
            if (dist <= 300) {
                client.equipHat("Soldier Helmet");
            }

            return;
        }

        client.equipHat("Booster Hat"); // no enemy? just use boost hat

        const wolf = ais.filter((e) => e.aiType == "Wolf")[0];

        // If wolf is nearby and you have no enemies: follow the wolf
        if (wolf) {
            BotState.lookAt = atan2(wolf, myPlayer);
            BotState.moveDir = BotState.lookAt;

            // if wolf is too close: move away
            if (hypot(wolf, myPlayer) <= 150) {
                BotState.moveDir = BotState.moveDir + Math.PI;
            }

            return;
        }

        const RESOURCE_FARM_LIMIT = 125;

        let resource: Entity | undefined;

        if (client.resources.stone < RESOURCE_FARM_LIMIT) {
            resource = this.gameObjects.find((e) => e.identity == "Stone");
        } else if (client.resources.wood < RESOURCE_FARM_LIMIT) {
            resource = this.gameObjects.find((e) => e.identity == "Tree");
        }

        // if no resource is found, or you farm enough: default to bush
        resource ||= this.gameObjects.find((e) => e.identity == "Bush");
        // if no resource is found. go to center of the map.
        resource ||= {
            x: 14400 / 2,
            y: 14400 / 2,
        };

        BotState.lookAt = atan2(resource, myPlayer);
        BotState.moveDir = BotState.lookAt;
    });

    client.on("update", function () {
        if (!client.myPlayer) return;

        const myPlayer = client.myPlayer;

        tick += 1;

        if (tick % 20 == 0) {
            client.sendJoinRequest("bot");
            client.place(client.foodType);
            client.place(client.millType, myPlayer.angle + Math.PI);

            if (BotState.fire) {
                client.hold(client.primaryWeapon, "weapon");
            }

            client.buyHat("Soldier Helmet");
            client.buyHat("Booster Hat");
        }

        client.setMovementDirection(BotState.moveDir);
        client.setAutoFire(BotState.fire, BotState.lookAt ?? myPlayer.angle);
        if (BotState.lookAt) {
            client.setDirection(BotState.lookAt);
        }
    });

    client.on("ready", spawn);
    client.on("death", spawn);

    client.on("TeamSignal", function (loc) {
        teamSignalLocation = loc;
    });

    client.on("age-up", function (age) {
        if (age == 2) return client.select(3);
        if (age == 3) return client.select(17);
        if (age == 4) return client.select(32);
        if (age == 5) return client.select(23);
        if (age == 6) return client.select(9);
        if (age == 7) return client.select(34);
        if (age == 8) return client.select(12);
        if (age == 9) return client.select(15);
    });

    client.on("chat", async ({ player, message }) => {
        if (!client.myPlayer) return;

        if (!player.isLeader || client.myPlayer.teamID != player.teamID) return;

        if (message == "!shoot") {
            // Disable the auto-fire
            BotState.fire = false;

            // Switch to secondary
            client.hold(
                client.secondaryWeapon ?? client.primaryWeapon,
                "weapon"
            );

            // SHOOT!
            client.setAutoFire(
                true,
                cheat.nearestEnemy
                    ? atan2(cheat.nearestEnemy, client.myPlayer)
                    : client.myPlayer.angle
            );
            client.setAutoFire(false);

            // do the reload thing
            await sleep(1500);

            // back to primary
            client.hold(client.primaryWeapon, "weapon");

            // Enable the auto-fire.
            BotState.fire = true;

            return;
        }

        client.chat(message);
    });
}

export default function connectBot(url: string) {
    const socket = new WebSocket(url, {
        headers: {
            origin: "https://mooomoo.io",
        },
    });

    socket.onopen = () => {
        const client = new Client(socket);
        const cheat = new CheatClient(client, {
            AutoHeal: "enable",
        });

        initClient(client, cheat);
    };
    socket.onclose = () => {
        console.log("onclose");
    };

    return socket;
}
