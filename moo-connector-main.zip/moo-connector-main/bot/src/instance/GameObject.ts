import Entity from "./Entity";
import { HPacketSchema } from "./Schema";

export default class GameObject implements Entity {
    readonly ownerID: number;
    readonly scale: number;
    readonly dataIndex: number | null;
    readonly type: number | null;
    readonly rotation: number;
    readonly x: number;
    readonly y: number;

    constructor(readonly id: number, chunk: Zod.infer<typeof HPacketSchema>) {
        this.ownerID = chunk[7];
        this.scale = chunk[4];
        this.dataIndex = chunk[6];
        this.type = chunk[5];
        this.rotation = chunk[3];
        this.x = chunk[1];
        this.y = chunk[2];
    }

    get identity() {
        if (this.type == 0) {
            return "Tree";
        }
        if (this.type == 1) {
            return this.y < 11989 ? "Bush" : "Cactus";
        }
        if (this.type == 2) {
            return this.biome == "River" ? "WaterStone" : "Stone";
        }
        if (this.type == 3) {
            return "Gold";
        }

        return "Unknown";
    }

    get biome() {
        if (this.y < 2400) {
            return "Snow";
        } else if (this.y > 6850 && this.y < 7550) {
            return "River";
        } else {
            return "Land";
        }
    }
}
