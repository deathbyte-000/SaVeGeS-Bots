import { z } from "zod";

export const APacketSchema = z.tuple([
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.string().nullable(), // 8
    z.union([z.number(), z.string()]),
    z.union([z.number(), z.string()]),
    z.number(),
    z.number(),
    z.number(),
]);

export const HPacketSchema = z.tuple([
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number().nullable(),
    z.number().nullable(),
    z.number(),
]);
export const IPacketSchema = z.tuple([
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
    z.number(),
]);
