export default interface Entity {
    x: number;
    y: number;
}
