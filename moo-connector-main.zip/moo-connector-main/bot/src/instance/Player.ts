import Entity from "./Entity";
import { APacketSchema } from "./Schema";

export default class Player implements Entity {
    public isBestKiller!: boolean;
    public weaponVariant!: number;
    public weaponType!: number;
    public buildType!: number;
    public isLeader!: boolean;
    public tailID!: number;
    public hatID!: number;
    public layer!: number;
    public teamID!: string | null;
    public angle!: number;
    public x!: number;
    public y!: number;

    public health = 100;
    public visible = false;

    constructor(readonly id: number, data: Zod.infer<typeof APacketSchema>) {
        this.update(data);
    }

    update(data: Zod.infer<typeof APacketSchema>) {
        this.visible = true;
        this.isBestKiller = !!data[11];
        this.weaponVariant = data[6];
        this.weaponType = data[5];
        this.buildType = data[4];
        this.isLeader = !!data[8];
        this.tailID = Number(data[10]);
        this.hatID = Number(data[9]);
        this.layer = data[12];
        this.teamID = data[7];
        this.angle = data[3];
        this.x = data[1];
        this.y = data[2];
    }

    setHealth(health: number) {
        this.health = typeof health == "number" ? health : 0;
    }

    get biome() {
        if (this.y < 2400) {
            return "Snow";
        } else if (this.y > 6850 && this.y < 7550) {
            return "River";
        } else {
            return "Land";
        }
    }
}
