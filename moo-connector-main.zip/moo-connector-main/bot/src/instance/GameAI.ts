import Entity from "./Entity";
import { IPacketSchema } from "./Schema";

export default class GameAI implements Entity {
    public type!: number;
    public rotation!: number;
    public health!: number;
    public x!: number;
    public y!: number;

    constructor(readonly id: number, chunk: Zod.infer<typeof IPacketSchema>) {
        this.update(chunk);
    }

    update(chunk: Zod.infer<typeof IPacketSchema>) {
        this.health = chunk[5];
        this.type = chunk[1];
        this.rotation = chunk[4];
        this.x = chunk[2];
        this.y = chunk[3];
    }

    get aiType() {
        return this.type == 4
            ? "Wolf"
            : this.type == 3
            ? "Bully"
            : this.type == 2
            ? "Bull"
            : this.type == 8
            ? "Moofie"
            : "Unknown";
    }

    get biome() {
        if (this.y < 2400) {
            return "Snow";
        } else if (this.y > 6850 && this.y < 7550) {
            return "River";
        } else {
            return "Land";
        }
    }
}
