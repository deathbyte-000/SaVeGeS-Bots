import Entity from "../instance/Entity";

export default function atan2(a: Entity, b: Entity) {
    return Math.atan2(a.y - b.y, a.x - b.x);
}
