export default class EventDriven<
    T extends Record<string, unknown>,
    Self extends EventDriven<T, Self>
> {
    private events = new Map<
        keyof T,
        {
            // TODO: Remove this any! :(
            callback: (payload: any) => void;
            id: number;

            once: boolean;
        }[]
    >();
    private idx = 0;

    once<N extends keyof T>(
        ev: N,
        callback: (this: Self, payload: T[N]) => void
    ): number {
        const id = ++this.idx;

        this.events.set(ev, [
            ...(this.events.get(ev) || []),
            {
                once: true,

                callback,
                id,
            },
        ]);

        return id;
    }

    on<N extends keyof T>(
        ev: N,
        callback: (this: Self, payload: T[N]) => void
    ): number {
        const id = ++this.idx;

        this.events.set(ev, [
            ...(this.events.get(ev) || []),
            {
                once: false,

                callback,
                id,
            },
        ]);

        return id;
    }

    emit<N extends keyof T>(ev: N, payload: T[N]): void {
        for (const e of this.events.get(ev) || []) {
            e.callback.call(this, payload);

            if (e.once) this.removeListener(ev, e.id);
        }
    }

    removeListener(ev: keyof T, id: number) {
        this.events.set(
            ev,
            (this.events.get(ev) || []).filter((e) => e.id != id)
        );
    }
}
