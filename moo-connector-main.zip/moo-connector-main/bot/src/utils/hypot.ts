import Entity from "../instance/Entity";

export default function hypot(a: Entity, b: Entity) {
    return Math.hypot(a.y - b.y, a.x - b.x);
}
