import puppeteer, { Browser } from "puppeteer";
import { z } from "zod";

const serversSchema = z.array(
    z.object({
        region: z.string(),
        name: z.string(),
        key: z.string(),
        playerCapacity: z.number(),
        playerCount: z.number(),
        version: z.string(),
    })
);

export type ServerData = z.infer<typeof serversSchema>[number] & {
    wss: string;
};

export async function createTokenGenerator(): Promise<{
    generateToken: () => Promise<string>;
    browser: Browser;
}> {
    console.log("Launching the browser...");
    const browser = await puppeteer.launch({
        args: ["--no-sandbox"],

        headless: true,
    });

    console.log("Creating new page...");
    const page = await browser.newPage();

    console.log("Navigating to https://moomoo.io");
    await page.goto("https://moomoo.io");

    const generateToken = () => {
        return page.evaluate(async function () {
            // @ts-expect-error
            const grecaptcha = window.grecaptcha;
            const token = await grecaptcha.execute(
                "6LfahtgjAAAAAF8SkpjyeYMcxMdxIaQeh-VoPATP",
                {
                    action: "homepage",
                }
            );

            return String(token);
        });
    };

    return { generateToken, browser };
}

export async function fetchServersData(
    belong: "sandbox" | "normal",
    version: string = "1.22"
): Promise<ServerData[]> {
    const subdomain = belong == "sandbox" ? "api-sandbox" : "api";
    const response = await fetch(
        `https://${subdomain}.moomoo.io/servers?v=${version}`
    );
    const json = await response.json();

    const data = serversSchema.parse(json);

    return data.map((server) => {
        return {
            ...server,
            wss: `wss://${server.key}.${server.region}.moomoo.io/`,
        };
    });
}
