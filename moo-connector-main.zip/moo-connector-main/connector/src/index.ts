import { readFileSync } from "fs";
import GlitchController from "./GlitchController";
import { createTokenGenerator, fetchServersData } from "./lib";
import prompt from "./utils/prompt";

const BOT_CONNECTOR_URLS = [
    "economic-zenith-answer",
    "second-early-grade",
    "sustaining-plant-language",
    "invented-sideways-aurora",
    // "spark-maddening-bolt",
    // "shocking-elegant-letter",
    // "wirehaired-cyclic-nerve",
    // "veiled-brainy-store",
    // "real-chip-sunfish",
    // "invited-fir-teeth",
    // "caramel-vivid-bolt",
].map((e) => `https://${e}.glitch.me/`);
const botScript = readFileSync("../bot/build/bot.js").toString();

interface BotConnector {
    disconnect(): Promise<void>;

    connectBot(url: string): Promise<unknown>;
    closeAll(): Promise<unknown>;

    reboot(): Promise<unknown>;
}

interface CommandEnv {
    generator: Awaited<ReturnType<typeof createTokenGenerator>>;
    connectors: BotConnector[];
}

const commands: {
    action(env: CommandEnv, ...args: string[]): Promise<void> | void;
    description: string;
    entry: string;

    parameters: {
        description: string;
        name: string;
    }[];
}[] = [
    {
        entry: "help",
        description: "Print help command!",
        parameters: [],
        action() {
            console.group("Commands:");
            for (const command of commands) {
                console.group(`- ${command.entry}: ${command.description}`);

                if (command.parameters.length) {
                    console.group("- Parameters:");
                }
                for (const param of command.parameters) {
                    console.log(`- ${param.name}: ${param.description}`);
                }
                if (command.parameters.length) {
                    console.groupEnd();
                }

                console.groupEnd();
            }
            console.groupEnd();
        },
    },
    {
        entry: "q",
        description:
            "exit the application and close all the bots in the process.",
        parameters: [],
        async action(env) {
            console.info("closing the bots...");
            for (const bc of env.connectors) {
                await bc.closeAll();
                await bc.disconnect();
            }

            console.info("closing the env...");
            await env.generator.browser.close();

            process.exit(0);
        },
    },
    {
        entry: "close-all",
        description: "close all the bots",
        parameters: [],
        async action(env) {
            for (const bc of env.connectors) {
                await bc.closeAll();
            }
            console.info("all bots are closed");
        },
    },
    {
        entry: "shutdown",
        description:
            "force reboot all connectors (useful if the connection is stuck)",
        parameters: [],
        async action(env) {
            console.info("Shutdown...");
            for (const bc of env.connectors) {
                await bc.reboot();
            }

            await env.generator.browser.close();
            process.exit(0);
        },
    },
    {
        entry: "join",
        description: "send bots to target server.",
        parameters: [
            {
                name: "kind",
                description: "server kind (e.g. sandbox)",
            },
            {
                name: "key",
                description: "server key (e.g. eu-west:WG)",
            },
        ],
        async action(env, kind, key) {
            if (kind !== "sandbox" && kind !== "normal") {
                return console.error(
                    "Expected first argument to be server kind (e.g. 'normal' or 'sandbox')"
                );
            }

            if (!key) {
                return console.error(
                    "Expected second argument to be server key (e.g. eu-west:WG)"
                );
            }

            const [region, name] = key.split(":");

            if (!region || !name)
                return console.error("key is not correctly formed.");

            console.info("Searching for server:", `${region}:${name}`);

            const servers = await fetchServersData(kind);

            const server =
                servers.find(
                    (e) =>
                        e.name.toLowerCase() == name.toLowerCase() &&
                        e.region.toLowerCase() == region.toLowerCase()
                ) || null;

            if (!server) {
                return console.error("No servers match the key:", key);
            }

            console.info(
                `Server[${key}]: activity(${server.playerCount}/${server.playerCapacity})`
            );

            console.info("Sending bots...");
            for (const bc of env.connectors) {
                for (let i = 0; i < 4; i++) {
                    const token = encodeURIComponent(
                        "re:" + (await env.generator.generateToken())
                    );

                    bc.connectBot(server.wss + "?token=" + token);
                }
            }
        },
    },
];

async function main() {
    console.group("Creating the environment");

    console.info("Preparing the connectors...");
    const connectors = await Promise.all(
        BOT_CONNECTOR_URLS.map(async (url) => {
            const gc = new GlitchController(url);
            await gc.waitToOpen();
            return await createBotConnector(gc);
        })
    );

    console.info("Creating generator...");
    const generator = await createTokenGenerator();

    const env: CommandEnv = {
        generator,
        connectors,
    };

    console.groupEnd();

    while (true) {
        const promptString = await prompt("> command: ");
        const [entry, ...args] = promptString.split(" ");

        const command = commands.find((c) => c.entry == entry);

        if (!command) {
            console.log("No command entry found:", entry);
            continue;
        }

        await command.action(env, ...args);
        console.log();
    }
}

async function createBotConnector(gc: GlitchController): Promise<BotConnector> {
    console.log("Creating bot connector for", gc.url);

    await gc.writeFile("bot.js", botScript);
    await gc.node(
        "globalStore.botConnect = requireUncached('./bot.js').default;globalStore.bots = [];"
    );

    return {
        disconnect() {
            return gc.disconnect();
        },
        async reboot() {
            return gc.reboot();
        },
        connectBot(url: string) {
            return gc.node(
                `globalStore.bots.push(globalStore.botConnect('${url}'))`
            );
        },
        closeAll() {
            return gc.node(
                `globalStore.bots.forEach(b => b.close());globalStore.bots = []`
            );
        },
    };
}

main();
