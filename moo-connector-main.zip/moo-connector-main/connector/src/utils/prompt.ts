import readline from "node:readline";

export default function prompt(question: string) {
    return new Promise<string>((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });

        rl.question(question, (answer) => {
            // TODO: Log the answer in a database
            resolve(String(answer));

            rl.close();
        });
    });
}
