import WebSocket from "ws";

export const SECRET_KEY = "SaVeGeIsTheOwner";

export default class GlitchController {
    private socket: WebSocket | null = null;

    constructor(readonly url: string) {
        this.__connect__();

        setInterval(this.__ping__.bind(this), 5e3);
    }

    // exec js on main thread.
    public node(code: string) {
        return this.send(["node", code]);
    }

    public cmd(cmd: string) {
        return this.send(["cmd", cmd]);
    }

    public writeFile(filename: string, content: string) {
        return this.send(["write_file", filename, content]);
    }

    public reboot() {
        this.send(["reboot"]);
        this.socket?.close();
    }

    public disconnect() {
        if (this.isOpen()) {
            this.reboot();
        }

        return this.waitToClose();
    }

    public isOpen() {
        return this.socket && this.socket.readyState == WebSocket.OPEN;
    }

    public async waitToOpen() {
        while (!this.isOpen()) {
            await new Promise((resolve) => setTimeout(resolve, 100));
        }
    }
    public async waitToClose() {
        while (this.socket && this.socket.readyState == WebSocket.CLOSED) {
            await new Promise((resolve) => setTimeout(resolve, 100));
        }
    }

    private send(
        packet:
            | ["cmd", string] // command to exec
            | ["node", string] // code to exec on main thread
            | ["write_file", string, string] // filename, file content
            | ["secret", string] // a key
            | ["reboot"]
            | ["ping"]
    ) {
        return new Promise((resolve) => {
            const packetID = Math.floor(Math.random() * 1000000);

            // TODO: Clean handlers if connection closed?
            const handler = ({ data }: { data: any }) => {
                if (typeof data !== "string") return;

                const [messageID, ...packet] = JSON.parse(data);

                if (messageID == packetID) {
                    this.socket?.removeEventListener("message", handler);
                    resolve(packet);
                }
            };

            this.socket?.addEventListener("message", handler);
            this.rawSend([packetID, ...packet]);
        });
    }

    private rawSend(packet: any[]) {
        if (!this.isOpen())
            throw new Error("Connection is either closed or not ready");

        this.socket?.send(JSON.stringify(packet));
    }

    private __connect__() {
        if (this.isOpen()) return;

        this.socket = new WebSocket(this.url.replace("http", "ws"), {
            headers: {
                "user-agent":
                    "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 7_1_6; en-US) Gecko/20100101 Firefox/53.8",
            },
        });

        this.socket.onopen = () => {
            this.send(["secret", SECRET_KEY]);
            this.__ping__();
        };
    }

    private __ping__() {
        if (this.isOpen()) this.send(["ping"]);
    }
}
