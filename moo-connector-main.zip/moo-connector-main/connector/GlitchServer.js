const http = require("http");
const WebSocket = require("ws");
const { execSync } = require("child_process");
const { writeFileSync } = require("fs");

var globalStore = {};

function requireUncached(module) {
    try {
        delete require.cache[require.resolve(module)];
    } catch (e) {}
    return require(module);
}

const SECRET_KEY = process.env["password"] || Math.random() * 1e6;

const server = http.createServer((_req, res) => {
    res.end("Nothing here.");
});
const wss = new WebSocket.Server({ server });

const bots = {};

wss.on("connection", (socket, req) => {
    let verified = false;

    const send = function (id, ...packet) {
        socket.send(JSON.stringify([id, ...packet]));
    };

    socket.on("message", (data) => {
        let packet;
        try {
            packet = JSON.parse(data.toString());

            if (!Array.isArray(packet)) throw new Error("Go to error");
        } catch (e) {
            return socket.close();
        }

        const [packetID, packetName, ...packetInfo] = packet;

        if (packetName == "secret") {
            verified = SECRET_KEY === packetInfo[0];

            !verified && socket.close();
            return;
        }

        if (!verified) return;

        if (packetName == "reboot") {
            throw new Error("Rebooting..");
        }
        if (packetName == "ping") {
            return send(packetID, "pong");
        }
        if (packetName == "cmd") {
            return send(packetID, execSync(packetInfo[0]).toString());
        }
        if (packetName == "node") {
            return send(packetID, eval(packetInfo[0]));
        }
        if (packetName == "write_file") {
            writeFileSync(...packetInfo);
            return send(packetID, packetInfo);
        }
    });
});

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
